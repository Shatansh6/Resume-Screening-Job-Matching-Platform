export const APPLICATION_STATUS = {
  APPLIED: "Applied",
  REVIEWED: "Reviewed",
  SELECTED: "Selected",
  REJECTED: "Rejected",
};
